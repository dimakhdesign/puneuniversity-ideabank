import React from "react";

const AuthContext = () => {
  return (
    <div>
      <h1>This page provides and Authentication Context</h1>
    </div>
  );
};

export default AuthContext;
