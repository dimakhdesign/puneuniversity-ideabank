export const API_KEY = 'D2GlxTqMpmnr9xptE3AN83LtCPsj6E';
// export const BASE_URL = '/api'; // Or the full URL if you’re not using a Vite proxy