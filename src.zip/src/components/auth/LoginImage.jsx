import React from "react";

const loginImage = () => {
  return (
    <div>
      <img src="/login-image.svg" alt="" />
    </div>
  );
};

export default loginImage;
