import loginImage from '../assets/login-image.svg'

const LoginImage = () => {
  return (
    <>
    <img src={loginImage} alt="" className="h-full rounded-md" />
    </>
  )
}

export default LoginImage
