import './MainContentWrapper.css';

const MainContentWrapper = () => {
    return (
        <div className="main-content-wrapper">
            <h1>Main Content</h1>
        </div>
    )
}

export default MainContentWrapper
