import React from 'react'

const Resources = () => {
    return (
        <p>No resources available at the moment.</p>
    )
}

export default Resources
