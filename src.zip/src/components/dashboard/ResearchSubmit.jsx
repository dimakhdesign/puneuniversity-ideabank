import FormField from '../auth/FormField';

const ResearchSubmit = () => {
    return (

        <FormField />
    )
}

export default ResearchSubmit
