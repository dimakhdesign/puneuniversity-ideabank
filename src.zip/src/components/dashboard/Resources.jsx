import React from 'react'

const Resources = () => {
    return (
        <p>There are no resources found.</p>
    )
}

export default Resources
