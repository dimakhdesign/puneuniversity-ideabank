import React from 'react'

const DocumentsRepository = () => {
    return (
        <p>No documents have been uploaded yet.</p>
    )
}

export default DocumentsRepository
