import React from 'react'

const AdminDiscussionForum = () => {
    return (
        <p>Q&A discussions will appear here once they begin.</p>
    )
}

export default AdminDiscussionForum
