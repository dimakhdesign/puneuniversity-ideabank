import React from 'react'

const Submissions = () => {
    return (
        <p>No submissions have been received yet.</p>
    )
}

export default Submissions
