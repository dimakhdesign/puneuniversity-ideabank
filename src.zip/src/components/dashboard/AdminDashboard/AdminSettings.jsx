import React from 'react'

const AdminSettings = () => {
    return (
        <p>Settings</p>
    )
}

export default AdminSettings
