import React from 'react'

const Settings = () => {
    return (
        <div>
            Settings & Profile
        </div>
    )
}

export default Settings
