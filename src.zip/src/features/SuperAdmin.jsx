import React from "react";

const SuperAdmin = () => {
  return (
    <div>
      <h1>This is Super Admin Dashboard</h1>
    </div>
  );
};

export default SuperAdmin;
