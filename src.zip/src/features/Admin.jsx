import React from "react";

const Admin = () => {
  return (
    <div>
      <h1>This is Admin Dashboard</h1>
    </div>
  );
};

export default Admin;
