import React from "react";

const Expert = () => {
  return (
    <div>
      <h1>This is Expert Dashboard</h1>
    </div>
  );
};

export default Expert;
